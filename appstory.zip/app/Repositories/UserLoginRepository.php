<?php
namespace App\Repositories;

interface UserLoginRepository extends BaseRepository
{

}
