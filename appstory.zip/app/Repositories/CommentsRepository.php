<?php
namespace App\Repositories;

interface CommentsRepository extends BaseRepository
{

}
