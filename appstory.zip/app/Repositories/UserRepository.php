<?php
namespace App\Repositories;

interface UserRepository extends BaseRepository
{

}
