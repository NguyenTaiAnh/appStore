<?php

namespace App\Repositories\Eloquent;

use App\Repositories\UserRepository;

class EloquentUserRepository extends EloquentBaseRepository implements UserRepository
{

}
