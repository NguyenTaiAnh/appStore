<?php

namespace App\Repositories\Eloquent;

use App\Repositories\UserRepository;

class EloquentUserLoginRepository extends EloquentBaseRepository implements UserRepository
{

}
