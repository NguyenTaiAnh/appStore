<?php

namespace App\Http\Controllers\Admin;

class UserLoginController extends Controller
{
    //
}
