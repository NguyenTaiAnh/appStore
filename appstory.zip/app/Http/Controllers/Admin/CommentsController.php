<?php

namespace App\Http\Controllers\Admin;

class CommentsController extends Controller
{
    //
}
